#ifndef FAMILYTREE_H_INCLUDED
#define FAMILYTREE_H_INCLUDED
#include<iostream>
#include<string>

using namespace std;

struct Person {
    int id;
    string name;
    string birthday;
    bool isMale, isAlive, isMarried;
    Person *leftOne, *rightOne;

    Person(int i, string n, string b, bool iMal, bool iAli = true,
    bool iMar = false, Person *l = NULL, Person *r = NULL) :
    id(i), name(n), birthday(b), isMale(iMal), isAlive(iAli), isMarried(iMar),
    leftOne(l), rightOne(r) {}
};

class familyTree {
public:
    familyTree(string name, bool isMale, string birthday);
    ~familyTree();
    void print(Person *subFamily) const;
    bool addBaby(int motherId);
    bool addWife(int loverId);
    bool queryWife(int loverId);
    bool queryChild(int fatherId);
    static int idCount;
private:
    void destroy(Person *subTree);
    Person* findSomeone(int id, Person* start = NULL);
    Person* findLastChildren(int motherId);
    Person* findLastWife(int loverId);
    Person *root;
};

#endif // FAMILYTREE_H_INCLUDED
