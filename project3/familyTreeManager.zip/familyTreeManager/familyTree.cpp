#include"familyTree.h"

int familyTree::idCount = 0;
familyTree::familyTree(string name, bool isMale, string birthday) {
    root = new Person(idCount, name, birthday, isMale);
    idCount++;
}

void destroy(Person *subTree) {
    if (subTree != NULL) {
        destroy(subTree->leftOne);
        destroy(subTree->rightOne);
        delete subTree;
    }
}
familyTree::~familyTree() {
    destroy(root);
}

void familyTree::print(Person *subFamily) const {
        return;
    if (NULL == subFamily)

    cout << subFamily->name << ' ';    //  husband

    Person *p = subFamily;
    while (p->rightOne != NULL){
        p = p->rightOne;
    }
    cout << p->name << endl;    //  present wife

    cout << "their children(or child)'s family: {" << endl;
    p = subFamily;
    while (p->rightOne != NULL) {
        p = p->rightOne;

        Person *q = p;
        while (q->leftOne != NULL) {
            q = q->leftOne;
            print(q);
        }
    }
    cout << '}' << endl;

}

bool familyTree::addBaby(Person newBaby, int motherId) {
    Person* lastChildren = findLastChildren(motherId);
    // validate
    if (lastChildren == NULL)
        return false;
    lastChildren->leftOne = new Person(newBaby);
    return true;
}

bool familyTree::addWife(Person newWife, int loverId) {
    Person* lastWife = findLastWife(loverId);
    // validate
    if (lastWife == NULL)
        return false;
    lastWife->rightOne = new Person(newWife);
    return true;
}

Person* familyTree::findSomeone(int id,  Person* start) {
    // start from root
    if (start == NULL)
        start = root;
    // check itself
    if (start->id == id)
        return start;
    // check leftOne
    if (start->leftOne) {
        Person* temp = this->findSomeone(id, start->leftOne);
        if (temp)
            return temp;
    }
    if (start->rightOne)
        return this->findSomeone(id, start->rightOne);
    return NULL;
}

Person* familyTree::findLastChildren(int motherId) {
    Person* mother = this->findSomeone(motherId);
    if (mother) {
        if (mother->isMale == false) {
            while (mother->leftOne)
                mother = mother->leftOne;
            return mother;
        } else {
            return NULL;
        }
    }
    return NULL;
}

Person* familyTree::findLastWife(int loverId) {
    Person* lover = this->findLastWife(loverId);
    if (lover) {
        if (lover->isMale) {
            while (lover->rightOne)
                lover = lover->rightOne;
            return lover;
        } else {
            return NULL;
        }
    }
    return NULL;
}

bool familyTree::queryWife(int loverId) {
    Person *p = findSomeone(loverId);

    if (NULL == p)
        return false;

    while (p->rightOne != NULL) {
        p = p->rightOne;
        cout << p->name << ' ' << p->id << endl;
    }

    return true;
}

bool familyTree::queryChild(int fatherId) {
    Person *p = findSomeone(fatherId);

    if (NULL == p)
        return false;

    while (p->rightOne != NULL) {
        p = p->rightOne;

        Person *q = p;
        while (q->leftOne != NULL) {
            q = q->leftOne;
            cout << q->name << ' ' << q->id << endl;
        }
    }

    return true;
}
