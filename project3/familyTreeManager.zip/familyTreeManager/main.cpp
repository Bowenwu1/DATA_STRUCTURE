#include"familyTree.h"

int main() {
    familyTree ft;

    return 0;
}
